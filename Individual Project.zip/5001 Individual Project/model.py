#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 10 02:18:58 2019

@author: ziwenwang
"""
# ============================================================================= Part 0
import pandas as pd
#from sklearn.ensemble import RandomForestRegressor
from lightgbm import LGBMRegressor
from xgboost import XGBRegressor
import pickle

# Define a Funtion Dealing with the Top Tags in 'Genres'
def top_genres(array):
    if str(array) == 'nan':
        return 0, 0, 0, 0
    
    Action, Adventure, Indie, Strategy = 0, 0, 0, 0
    for i in array.split(','):
            if str(i) == 'Action':
                Action += 1
            if str(i) == 'Adventure':
                Adventure += 1
            if str(i) == 'Indie':
                Indie += 1
            if str(i) == 'Strategy':
                Strategy += 1
        
    return Action, Adventure, Indie, Strategy

# ============================================================================= Part 1 Load the Data
data = pd.read_csv('train.csv', index_col=0)
data['purchase_date'] = pd.to_datetime(data['purchase_date'])
data['release_date'] = pd.to_datetime(data['release_date'])
# Deal with the Format of the time
data['purchase_date'] = data['purchase_date'].dt.strftime('%m-%d-%Y')
data['release_date'] = data['release_date'].dt.strftime('%m-%d-%Y')
data['purchase_date'] = pd.to_datetime(data['purchase_date'])
data['release_date'] = pd.to_datetime(data['release_date'])

# ============================================================================= Part 2 Data Processing and Feature Engineering
# New Features: 'Action', 'Adventure', 'Indie', 'Strategy'
data[['Action', 'Adventure', 'Indie', 'Strategy']] = pd.DataFrame(data['genres'].apply(top_genres).tolist(), index=data.index)
data.drop(columns=['genres'], inplace=True)

data_X =  data.drop(columns=['categories', 'tags', 'playtime_forever'])
data_Y = data['playtime_forever']

# New Features: 'time_difference' and 'positiveness'
data_X['time_difference'] = data['purchase_date'] - data['release_date']
data_X['positiveness'] = data['total_positive_reviews'] / data ['total_negative_reviews']


mapping = dict()
# Use Numerical Representation for the Date
data_X['purchase_date'], mapping['purchase_date'] = pd.factorize(data_X['purchase_date'])[0], pd.factorize(data_X['purchase_date'])[1]
data_X['release_date'], mapping['release_date'] = pd.factorize(data_X['release_date'])[0], pd.factorize(data_X['release_date'])[1]
data_X['time_difference'], mapping['time_difference'] = pd.factorize(data_X['time_difference'])[0], pd.factorize(data_X['time_difference'])[1]

file = open('mapping.pickle', 'wb')
pickle.dump(mapping, file)
file.close()

# ============================================================================= Part 3 Train Model
# XGBoosting
#model = XGBRegressor()

# LGBM
model = LGBMRegressor()

model.fit(data_X, data_Y)

file = open('model.pickle', 'wb')
pickle.dump(model, file)
file.close()
print("Model Has Been Saved!")

#data['playtime_forever'] = pd.DataFrame(model.predict(data_X)[:,1])

