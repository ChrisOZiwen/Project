#MSBD 5001 Individual Project
#ZIWEN WANG

Environment: Python 3

The packages needed for the project are list as below:
pandas
lightbgm
xgboost
pickle

Run the model.py to train the model.
Then run the prediction.py to generate output.

The submissions I used on Kaggle are stored under the file of 'Outputs'.



