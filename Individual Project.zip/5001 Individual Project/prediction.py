#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 10 02:42:32 2019

@author: ziwenwang
"""
# ============================================================================= Part 0
import pickle
import pandas as pd

# Define a Funtion Dealing with the Top Tags in 'Genres'
def top_genres(array):
    if str(array) == 'nan':
        return 0, 0, 0, 0
    
    Action, Adventure, Indie, Strategy = 0, 0, 0, 0
    for i in array.split(','):
            if str(i) == 'Action':
                Action += 1
            if str(i) == 'Adventure':
                Adventure += 1
            if str(i) == 'Indie':
                Indie += 1
            if str(i) == 'Strategy':
                Strategy += 1
        
    return Action, Adventure, Indie, Strategy

# ============================================================================= Part 1 
file = open('mapping.pickle', 'rb')
mapping = pickle.load(file)
file.close()
file = open('model.pickle', 'rb')
model = pickle.load(file)
file.close()

data = pd.read_csv('test.csv', index_col=0)
data['purchase_date'] = pd.to_datetime(data['purchase_date'])
data['release_date'] = pd.to_datetime(data['release_date'])
# Deal with the Format of the time
data['purchase_date'] = data['purchase_date'].dt.strftime('%m-%d-%Y')
data['release_date'] = data['release_date'].dt.strftime('%m-%d-%Y')
data['purchase_date'] = pd.to_datetime(data['purchase_date'])
data['release_date'] = pd.to_datetime(data['release_date'])

# ============================================================================= Part 2 Data Processing and Feature Engineering
# New Features: 'Action', 'Adventure', 'Indie', 'Strategy'
data[['Action', 'Adventure', 'Indie', 'Strategy']] = pd.DataFrame(data['genres'].apply(top_genres).tolist(), index=data.index)
data.drop(columns=['genres'], inplace=True)

data_X =  data.drop(columns=['categories', 'tags'])

# New Features: 'time_difference' and 'positiveness'
data_X['time_difference'] = data['purchase_date'] - data['release_date']
data_X['positiveness'] = data['total_positive_reviews'] / data ['total_negative_reviews']

data['playtime_forever'] = 0
data_Y = data['playtime_forever']

for h in data_X['purchase_date'].unique():
  if h not in mapping['purchase_date']:
    mapping['purchase_date'] = mapping['purchase_date'].append(pd.Index([h]))
  
for h in data_X['release_date'].unique():
  if h not in mapping['release_date']:
    mapping['release_date'] = mapping['release_date'].append(pd.Index([h]))
    
for h in data_X['time_difference'].unique():
  if h not in mapping['time_difference']:
    mapping['time_difference'] = mapping['time_difference'].append(pd.Index([h]))

for key in mapping:
    data_X[key].replace(pd.Series(index=mapping[key], data=range(len(mapping[key]))),
          inplace = True)
    data_X[key] = data_X[key].astype(int)    
    
# ============================================================================= Part 3 Predict
data['playtime_forever'] = pd.DataFrame(model.predict(data_X), index=data_X.index)
data['playtime_forever'] = data['playtime_forever'] * (data['playtime_forever'] >= 0)

data_pre =  data.drop(columns=['Action', 'Adventure', 'Indie', 'Strategy', 'tags', 'is_free', 'price', 'categories', 'tags', 'purchase_date', 'release_date','total_positive_reviews', 'total_negative_reviews'])
data_pre.to_csv("output.csv")

